import { firebaseAuth } from '@/lib/firebase';

const API_BASE = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '');

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!API_BASE) throw new Error('LineGuard secure server is not configured. Please try again after the service is deployed.');
  const user = firebaseAuth.currentUser;
  if (!user) throw new Error('Please sign in again.');
  const token = await user.getIdToken();
  const response = await fetch(`${API_BASE}/api${path}`, {
    ...init,
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}`, ...(init.headers || {}) },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof body.error === 'string' ? body.error : 'The secure service request failed.');
  return body as T;
}

export type ServerCase = {
  caseId: string; reporterId: string; reporterName?: string; accusedId?: string | null;
  description: string; location?: { address?: string }; evidence?: string[]; evidenceTypes?: ("image" | "video")[];
  status: string; createdAt?: any; paymentStatus?: string; reporterConfirmed?: boolean; accusedConfirmed?: boolean; agreedCompensation?: number | null;
  agreedCompensation?: number | null; paidAt?: any;
};
export type NewCaseResult = { caseId: string; invitationCode: string; status: string };

export const createSecureCase = (payload: { description: string; reporterName: string; location: { latitude: number; longitude: number; address: string }; evidence: string[]; evidenceTypes?: ("image" | "video")[] }) =>
  request<NewCaseResult>('/cases', { method: 'POST', body: JSON.stringify(payload) });
export const listSecureCases = () => request<{ cases: ServerCase[] }>('/cases');
export const joinSecureCase = (invitationCode: string) => request<{ caseId: string; status: string }>('/cases/join', { method: 'POST', body: JSON.stringify({ invitationCode }) });
export const confirmSecureCase = (caseId: string, agreedCompensation: number) => request<{ ok: boolean }>(`/cases/${encodeURIComponent(caseId)}/confirm`, { method: 'POST', body: JSON.stringify({ agreedCompensation }) });
export const disputeSecureCase = (caseId: string, reason: string) => request<{ ok: boolean }>(`/cases/${encodeURIComponent(caseId)}/dispute`, { method: 'POST', body: JSON.stringify({ reason }) });
export const createSecurePaymentOrder = (caseId: string) => request<{ orderId: string; amount: number; currency: string; keyId: string; checkoutUrl: string }>(`/cases/${encodeURIComponent(caseId)}/payment-order`, { method: 'POST' });
export const getEvidenceUrl = (caseId: string, index: number) => request<{ url: string }>(`/cases/${encodeURIComponent(caseId)}/evidence/${index}`);
export async function uploadEvidenceAsset(uri: string, contentType: string, size?: number): Promise<string> {
  const prepared = await request<{ uploadUrl: string; objectPath: string; contentType: string }>('/evidence/upload-url', { method: 'POST', body: JSON.stringify({ contentType, size: size || 1 }) });
  const fileResponse = await fetch(uri);
  const blob = await fileResponse.blob();
  const uploaded = await fetch(prepared.uploadUrl, { method: 'PUT', headers: { 'content-type': prepared.contentType }, body: blob });
  if (!uploaded.ok) throw new Error('Evidence upload failed. Please retry.');
  return prepared.objectPath;
}
