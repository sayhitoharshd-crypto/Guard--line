import { Feather } from "@expo/vector-icons";
import { signInWithPhoneNumber } from "@react-native-firebase/auth";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { firebaseAuth } from "@/lib/firebase";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export default function PhoneAuthScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { completePhoneProfile } = useApp();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("+91 ");
  const [code, setCode] = useState("");
  const [confirmation, setConfirmation] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const topPad = Platform.OS === "web" ? 24 : insets.top;
  const bottomPad = Platform.OS === "web" ? 24 : insets.bottom;

  const sendCode = async () => {
    setError("");
    setNotice("");
    const normalized = phone.replace(/[\s()-]/g, "");
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) {
      setError("Enter a valid number with country code, for example +91 9876543210.");
      return;
    }
    setLoading(true);
    try {
      Keyboard.dismiss();
      const result = await signInWithPhoneNumber(firebaseAuth, normalized);
      setConfirmation(result);
      setNotice("Verification code sent. Check your SMS messages.");
    } catch (e: any) {
      setError(e?.message || "Could not send the SMS. Please check the number and try again.");
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    setError("");
    if (!confirmation) return;
    if (!/^\d{6}$/.test(code.trim())) {
      setError("Enter the 6-digit verification code.");
      return;
    }
    setLoading(true);
    try {
      Keyboard.dismiss();
      await confirmation.confirm(code.trim());
      await completePhoneProfile(name);
      router.replace("/(tabs)");
    } catch (e: any) {
      setError(e?.message || "That code could not be verified. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[colors.gradientStart, colors.gradientMid]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.header, { paddingTop: topPad + 18 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.back}>
          <Feather name="arrow-left" size={22} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.title}>Phone verification</Text>
        <Text style={styles.subtitle}>Sign in securely with a one-time SMS code.</Text>
      </LinearGradient>
      <KeyboardAwareScrollView contentContainerStyle={[styles.form, { paddingBottom: bottomPad + 28 }]} keyboardShouldPersistTaps="handled" bottomOffset={24}>
        {!!error && <View style={[styles.message, { backgroundColor: colors.destructive + "18", borderColor: colors.destructive + "55" }]}><Feather name="alert-circle" size={16} color={colors.destructive} /><Text style={[styles.messageText, { color: colors.destructive }]}>{error}</Text></View>}
        {!!notice && <View style={[styles.message, { backgroundColor: "#16A34A14", borderColor: "#16A34A55" }]}><Feather name="check-circle" size={16} color="#16A34A" /><Text style={[styles.messageText, { color: "#15803D" }]}>{notice}</Text></View>}
        {!confirmation ? <>
          <View style={styles.field}>
            <Text style={[styles.label, { color: colors.foreground }]}>Your name (optional)</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="user" size={17} color={colors.mutedForeground} /><TextInput value={name} onChangeText={setName} placeholder="Your name" placeholderTextColor={colors.mutedForeground} autoCapitalize="words" style={[styles.input, { color: colors.foreground }]} /></View>
          </View>
          <View style={styles.field}>
            <Text style={[styles.label, { color: colors.foreground }]}>Mobile number</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="smartphone" size={17} color={colors.mutedForeground} /><TextInput value={phone} onChangeText={setPhone} placeholder="+91 9876543210" placeholderTextColor={colors.mutedForeground} keyboardType="phone-pad" autoComplete="tel" style={[styles.input, { color: colors.foreground }]} /></View>
            <Text style={[styles.helper, { color: colors.mutedForeground }]}>Include the country code. India: +91.</Text>
          </View>
        </> : <View style={styles.field}>
          <Text style={[styles.label, { color: colors.foreground }]}>6-digit SMS code</Text>
          <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="message-square" size={17} color={colors.mutedForeground} /><TextInput value={code} onChangeText={setCode} placeholder="123456" placeholderTextColor={colors.mutedForeground} keyboardType="number-pad" maxLength={6} autoComplete="sms-otp" style={[styles.input, { color: colors.foreground, letterSpacing: 8 }]} /></View>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>Enter the code sent to {phone.trim()}.</Text>
        </View>}
        <Pressable onPress={confirmation ? verifyCode : sendCode} disabled={loading} style={styles.buttonOuter}>
          <LinearGradient colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.button}>
            {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.buttonText}>{confirmation ? "Verify and continue" : "Send verification code"}</Text>}
          </LinearGradient>
        </Pressable>
        {confirmation && <TouchableOpacity onPress={() => { setConfirmation(null); setCode(""); setNotice(""); setError(""); }} style={styles.changeNumber}><Text style={[styles.link, { color: colors.primary }]}>Change phone number</Text></TouchableOpacity>}
        <Text style={[styles.footnote, { color: colors.mutedForeground }]}>SMS delivery depends on Firebase phone-auth configuration and your carrier. Standard SMS charges may apply.</Text>
      </KeyboardAwareScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 24, paddingBottom: 28, gap: 8 },
  back: { width: 40, height: 40, justifyContent: "center", marginBottom: 10 },
  title: { color: "#FFF", fontSize: 30, fontFamily: "Inter_700Bold" },
  subtitle: { color: "rgba(255,255,255,0.78)", fontSize: 14, fontFamily: "Inter_400Regular" },
  form: { padding: 24, gap: 18 },
  field: { gap: 7 },
  label: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  inputWrap: { minHeight: 54, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 10 },
  input: { flex: 1, fontSize: 16, paddingVertical: 14, fontFamily: "Inter_400Regular" },
  helper: { fontSize: 12, fontFamily: "Inter_400Regular" },
  message: { borderWidth: 1, borderRadius: 12, padding: 12, flexDirection: "row", alignItems: "center", gap: 8 },
  messageText: { flex: 1, fontSize: 13, fontFamily: "Inter_500Medium" },
  buttonOuter: { borderRadius: 15, overflow: "hidden", marginTop: 4 },
  button: { minHeight: 54, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  buttonText: { color: "#FFF", fontSize: 16, fontFamily: "Inter_700Bold" },
  changeNumber: { alignItems: "center", padding: 8 },
  link: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  footnote: { textAlign: "center", fontSize: 11, lineHeight: 17, marginTop: 8, fontFamily: "Inter_400Regular" },
});
