import { Router, type IRouter } from 'express';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { adminDb, adminBucket, FieldValue } from '../lib/firebase-admin';
import { requireAuth } from '../middlewares/require-auth';

const router: IRouter = Router();
const clean = (v: unknown, max = 2000) => typeof v === 'string' ? v.trim().slice(0, max) : '';
const isMember = (data: any, uid: string) => data.reporterId === uid || data.accusedId === uid;

router.post('/cases', requireAuth, async (req, res) => {
  try {
    const uid = req.user!.uid;
    const description = clean(req.body?.description, 2000);
    const address = clean(req.body?.location?.address, 300);
    const amount = Number(req.body?.requestedCompensation ?? 0);
    if (description.length < 10) return res.status(400).json({ error: 'Description must be at least 10 characters.' });
    if (!Number.isFinite(amount) || amount < 0 || amount > 200) return res.status(400).json({ error: 'Total compensation must be between ₹0 and ₹200; the reporter share is capped at ₹100.' });
    const incomingEvidence = Array.isArray(req.body?.evidence) ? req.body.evidence.filter((x: unknown) => typeof x === 'string').slice(0, 5) as string[] : [];
    if (incomingEvidence.some(path => !path.startsWith(`evidence-staging/${uid}/`))) return res.status(400).json({ error: 'Evidence upload reference is invalid.' });
    const incomingEvidence = Array.isArray(req.body?.evidence) ? req.body.evidence.filter((x: unknown) => typeof x === 'string').slice(0, 5) as string[] : [];
    if (incomingEvidence.some(path => !path.startsWith(`evidence-staging/${uid}/`))) return res.status(400).json({ error: 'Evidence upload reference is invalid.' });
    const caseId = randomUUID();
    const evidencePaths: string[] = [];
    for (const sourcePath of incomingEvidence) {
      const source = adminBucket.file(sourcePath);
      const [exists] = await source.exists();
      if (!exists) return res.status(400).json({ error: 'An uploaded evidence file is missing. Please upload it again.' });
      const [metadata] = await source.getMetadata();
      if (Number(metadata.size || 0) > 25 * 1024 * 1024) return res.status(400).json({ error: 'Each evidence file must be 25 MB or smaller.' });
      const destination = `cases/${caseId}/${randomUUID()}`;
      await source.move(destination);
      evidencePaths.push(destination);
    }
    const evidencePaths: string[] = [];
    for (const sourcePath of incomingEvidence) {
      const source = adminBucket.file(sourcePath);
      const [exists] = await source.exists();
      if (!exists) return res.status(400).json({ error: 'An uploaded evidence file is missing. Please upload it again.' });
      const [metadata] = await source.getMetadata();
      if (Number(metadata.size || 0) > 25 * 1024 * 1024) return res.status(400).json({ error: 'Each evidence file must be 25 MB or smaller.' });
      const destination = `cases/${caseId}/${randomUUID()}`;
      await source.move(destination);
      evidencePaths.push(destination);
    }
    const invitationCode = randomBytes(18).toString('base64url');
    const now = FieldValue.serverTimestamp();
    const record = {
      caseId, reporterId: uid, reporterName: clean(req.body?.reporterName, 80),
      accusedId: null, status: 'awaiting_accused', description, location: { address },
      evidence: evidencePaths,
      evidenceTypes: Array.isArray(req.body?.evidenceTypes) ? req.body.evidenceTypes.slice(0, evidencePaths.length).map((x: unknown) => x === 'video' ? 'video' : 'image') : evidencePaths.map(() => 'image'),
      requestedCompensation: amount, agreedCompensation: null, reporterConfirmed: false,
      accusedConfirmed: false, invitationCodeHash: createHash('sha256').update(invitationCode).digest('hex'),
      paymentStatus: 'not_started', createdAt: now, updatedAt: now,
    };
    await adminDb.collection('cases').doc(caseId).create(record);
    await adminDb.collection('caseEvents').add({ caseId, actorId: uid, type: 'case_created', at: now });
    return res.status(201).json({ caseId, invitationCode, status: record.status });
  } catch (error) {
    req.log?.error({ error }, 'case create failed');
    return res.status(500).json({ error: 'Could not create case.' });
  }
});

router.post('/cases/join', requireAuth, async (req, res) => {
  const code = clean(req.body?.invitationCode, 100);
  if (code.length < 16) return res.status(400).json({ error: 'Invalid invitation code.' });
  const hash = createHash('sha256').update(code).digest('hex');
  const found = await adminDb.collection('cases').where('invitationCodeHash', '==', hash).limit(1).get();
  if (found.empty) return res.status(404).json({ error: 'Invitation not found or expired.' });
  const ref = found.docs[0].ref;
  try {
    const result = await adminDb.runTransaction(async tx => {
      const snap = await tx.get(ref);
      const data = snap.data()!;
      if (data.reporterId === req.user!.uid) throw new Error('The reporter cannot join their own case as the accused party.');
      if (data.accusedId && data.accusedId !== req.user!.uid) throw new Error('This invitation has already been used.');
      if (data.status !== 'awaiting_accused') throw new Error('This case is no longer accepting a participant.');
      tx.update(ref, { accusedId: req.user!.uid, accusedConfirmed: false, status: 'awaiting_confirmation', invitationCodeHash: FieldValue.delete(), updatedAt: FieldValue.serverTimestamp() });
      tx.create(adminDb.collection('caseEvents').doc(), { caseId: snap.id, actorId: req.user!.uid, type: 'accused_joined', at: FieldValue.serverTimestamp() });
      return { caseId: snap.id, status: 'under_review' };
    });
    return res.json(result);
  } catch (e) { return res.status(409).json({ error: e instanceof Error ? e.message : 'Could not join case.' }); }
});

router.get('/cases', requireAuth, async (req, res) => {
  try {
    const uid = req.user!.uid;
    const [asReporter, asAccused] = await Promise.all([
      adminDb.collection('cases').where('reporterId', '==', uid).limit(100).get(),
      adminDb.collection('cases').where('accusedId', '==', uid).limit(100).get(),
    ]);
    const unique = new Map<string, any>();
    [...asReporter.docs, ...asAccused.docs].forEach(d => { const x = d.data(); delete x.invitationCodeHash; unique.set(d.id, { ...x, caseId: d.id }); });
    const cases = await Promise.all([...unique.values()].map(async item => ({ ...item, evidence: await Promise.all((item.evidence || []).map(async (path: string) => { const [url] = await adminBucket.file(path).getSignedUrl({ version: 'v4', action: 'read', expires: Date.now() + 15 * 60 * 1000 }); return url; })) })));
    return res.json({ cases });
  } catch (error) { req.log?.error({ error }, 'case list failed'); return res.status(500).json({ error: 'Could not load cases.' }); }
});

router.get('/cases/:caseId', requireAuth, async (req, res) => {
  const snap = await adminDb.collection('cases').doc(req.params.caseId).get();
  if (!snap.exists || !isMember(snap.data(), req.user!.uid)) return res.status(404).json({ error: 'Case not found.' });
  const data = snap.data()!; delete data.invitationCodeHash;
  const evidence = await Promise.all((data.evidence || []).map(async (path: string) => { const [url] = await adminBucket.file(path).getSignedUrl({ version: 'v4', action: 'read', expires: Date.now() + 15 * 60 * 1000 }); return url; }));
  return res.json({ ...data, evidence, caseId: snap.id });
});

router.post('/cases/:caseId/confirm', requireAuth, async (req, res) => {
  const agreed = Number(req.body?.agreedCompensation);
  if (!Number.isFinite(agreed) || agreed < 1 || agreed > 200) return res.status(400).json({ error: 'Total agreed compensation cannot exceed ₹200; the reporter share is capped at ₹100.' });
  try {
    await adminDb.runTransaction(async tx => {
      const ref = adminDb.collection('cases').doc(req.params.caseId);
      const snap = await tx.get(ref); if (!snap.exists) throw new Error('Case not found.');
      const d = snap.data()!; if (!isMember(d, req.user!.uid)) throw new Error('Not a case participant.');
      if (!d.accusedId) throw new Error('The second participant must join first.');
      if (d.status === 'disputed' || d.status === 'resolved') throw new Error('This case is closed to confirmation.');
      const reporterConfirmed = d.reporterConfirmed || d.reporterId === req.user!.uid;
      const accusedConfirmed = d.accusedConfirmed || d.accusedId === req.user!.uid;
      if (d.agreedCompensation !== null && d.agreedCompensation !== agreed) throw new Error('Both parties must confirm the same amount.');
      const both = reporterConfirmed && accusedConfirmed;
      tx.update(ref, { reporterConfirmed, accusedConfirmed, agreedCompensation: agreed, status: both ? 'agreed' : 'awaiting_confirmation', updatedAt: FieldValue.serverTimestamp() });
      tx.create(adminDb.collection('caseEvents').doc(), { caseId: snap.id, actorId: req.user!.uid, type: 'compensation_confirmed', agreedCompensation: agreed, at: FieldValue.serverTimestamp() });
    });
    return res.json({ ok: true });
  } catch (e) { return res.status(409).json({ error: e instanceof Error ? e.message : 'Confirmation failed.' }); }
});

router.post('/cases/:caseId/dispute', requireAuth, async (req, res) => {
  const reason = clean(req.body?.reason, 1000);
  if (reason.length < 10) return res.status(400).json({ error: 'Please provide a dispute reason of at least 10 characters.' });
  try {
    await adminDb.runTransaction(async tx => {
      const ref = adminDb.collection('cases').doc(req.params.caseId); const snap = await tx.get(ref);
      if (!snap.exists || !isMember(snap.data(), req.user!.uid)) throw new Error('Case not found.');
      if (['resolved', 'disputed'].includes(snap.data()!.status)) throw new Error('Case is already closed or disputed.');
      tx.update(ref, { status: 'disputed', updatedAt: FieldValue.serverTimestamp() });
      tx.create(adminDb.collection('caseEvents').doc(), { caseId: snap.id, actorId: req.user!.uid, type: 'dispute_opened', reason, at: FieldValue.serverTimestamp() });
    });
    return res.json({ ok: true, status: 'disputed' });
  } catch (e) { return res.status(409).json({ error: e instanceof Error ? e.message : 'Could not open dispute.' }); }
});

export default router;
