import { Router, type IRouter } from "express";
import healthRouter from "./health";
import casesRouter from "./cases";
import paymentsRouter from "./payments";
import sheetsRouter from "./sheets";
import evidenceRouter from "./evidence";
import evidenceRouter from "./evidence";

const router: IRouter = Router();

router.use(healthRouter);
router.use(casesRouter);
router.use(paymentsRouter);
router.use(sheetsRouter);
router.use(evidenceRouter);
router.use(evidenceRouter);

export default router;
